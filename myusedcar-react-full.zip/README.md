# MyUsedCar 完整版

1. 複製 .env.example 為 .env 並填入 Firebase 設定
2. npm install
3. npm run dev 啟動開發伺服器
