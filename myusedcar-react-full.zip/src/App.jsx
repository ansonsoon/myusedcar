import React from 'react';

function App() {
  return <h1>MyUsedCar - 完整版系統 Coming Soon</h1>;
}

export default App;